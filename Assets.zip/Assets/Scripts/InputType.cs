public static class InputType
{
    // Menu Input
    public static string InventoryMenu = "InventoryOpen";
    public static string EscapeMenu = "UI_Esc";
    public static string Text = "Text";
}
