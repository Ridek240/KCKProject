﻿public enum UIStatus
{
    InGame = 0,
    EscapeMenu = 1,
    InventoryMenu = 2,
    CraftingMenu = 3
}
